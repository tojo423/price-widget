const jsdom = require("jsdom");
const { JSDOM } = jsdom;

function getProductPrice(url) {
  return JSDOM.fromURL(url, {
    //   url: url,
    referrer: "https://www.newegg.com/",
    //   contentType: "text/html",
    includeNodeLocations: true,
    //storageQuota: 10000000,
    // pretendToBeVisual: true,
    userAgent:
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
    cookieJar: new jsdom.CookieJar(),
  })
    .then((dom) => {
      require("fs").writeFileSync("neweggresponse.html", dom.serialize());
      //console.log(dom.serialize());

      console.log("[Newegg] dom loaded!");

      const document = dom.window.document;
      const priceElements = document.querySelectorAll(
        ".product-buy-box .price-current"
      );
      priceElements.forEach((e) => {
        console.log("forEach e = ", e.textContent);
      });

      console.log("[Newegg] Price Elements:", priceElements);

      //const probablePriceSpan = priceSpans[Math.min(1, priceSpans.length - 1)];

      const price = priceElements[priceElements.length - 1].textContent;
      console.log("[Newegg] inside routine price", price);

      return price;
    })
    .catch((err) => {
      console.log("[newegg] Failed to get price...", err);
      return "N/A";
    });
}
